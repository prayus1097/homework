#ifndef DIFI_H
#define DIFI_H

#include <QObject>

class difi : public QObject
{
    Q_OBJECT
public:
    explicit difi(QObject *parent = nullptr);

signals:

};

#endif // DIFI_H
