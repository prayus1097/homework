#include "easy.h"
#include <QPaintEvent>
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QList>
#include "button.h"


easy::easy(QWidget *parent)
    : QMainWindow(parent)
{
    this->setFixedSize(1024,1024);
//按下建塔,共五个。
    Button*ta1=new Button(":/set.png");
    ta1->setParent(this);
    ta1->move(940,180);
    connect(ta1,&Button::clicked,this,&easy::jianta1);

    Button*ta2=new Button(":/set.png");
    ta2->setParent(this);
    ta2->move(600,120);
    connect(ta2,&Button::clicked,this,&easy::jianta2);

    Button*ta3=new Button(":/set.png");
    ta3->setParent(this);
    ta3->move(380,400);
    connect(ta3,&Button::clicked,this,&easy::jianta3);

    Button*ta4=new Button(":/set.png");
    ta4->setParent(this);
    ta4->move(380,580);
    connect(ta4,&Button::clicked,this,&easy::jianta4);

    Button*ta5=new Button(":/set.png");
    ta5->setParent(this);
    ta5->move(570,580);
    connect(ta5,&Button::clicked,this,&easy::jianta5);


}

void easy::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/map1.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    foreach(tower*tower,tower_list)
        tower->draw(&painter);
}

void easy::jianta1(){
    tower*new_tower=new tower(QPoint(920,170),":/ta 1.png");
    tower_list.push_back(new_tower);
    update();
}

void easy::jianta2(){
    tower*new_tower=new tower(QPoint(580,110),":/ta 1.png");
    tower_list.push_back(new_tower);
    update();
}

void easy::jianta3(){
    tower*new_tower=new tower(QPoint(360,390),":/ta 2.png");
    tower_list.push_back(new_tower);
    update();
}

void easy::jianta4(){
    tower*new_tower=new tower(QPoint(360,570),":/ta 2.png");
    tower_list.push_back(new_tower);
    update();
}

void easy::jianta5(){
    tower*new_tower=new tower(QPoint(550,570),":/ta 3.png");
    tower_list.push_back(new_tower);
    update();
}
