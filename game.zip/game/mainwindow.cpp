#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include "button.h"
#include "choose.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    //绘制开始屏幕
    this->setFixedSize(1024,1024);
    ui->setupUi(this);
    //加上背景音乐

    //控制背景音乐开关

    //加游戏开始按钮，有跳转效果
    Button*anniu=new Button(":/start.png");
    anniu->setParent(this);
    anniu->move(412,815);
    //跳转
    choose *scene=new choose;
    connect(anniu,&QPushButton::clicked,this,[=](){
        this->close();
        scene->show();
    });


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/first.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}


