#ifndef DIFFI_H
#define DIFFI_H

#include <QMainWindow>
#include "tower.h"
#include <QList>

class diffi : public QMainWindow
{
    Q_OBJECT
public:
    explicit diffi(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void jianta1();
    void jianta2();
    void jianta3();
    void jianta4();
    void jianta5();
private:
    QList<tower*>tower_list;
signals:

};

#endif // DIFFI_H
