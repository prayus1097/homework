#ifndef EASY_H
#define EASY_H

#include <QMainWindow>
#include "tower.h"
#include <QList>

class easy : public QMainWindow
{
    Q_OBJECT
public:
    explicit easy(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
    void jianta1();
    void jianta2();
    void jianta3();
    void jianta4();
    void jianta5();
private:
    QList<tower*>tower_list;
signals:
};

#endif // EASY_H
