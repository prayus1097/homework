#include "diffi.h"
#include <QPaintEvent>
#include <QPainter>
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include <QList>
#include "button.h"



diffi::diffi(QWidget *parent)
    : QMainWindow(parent)
{
    this->setFixedSize(1024,1024);
//按下建塔,共五个。
    Button*ta1=new Button(":/set.png");
    ta1->setParent(this);
    ta1->move(940,180);
    connect(ta1,&Button::clicked,this,&diffi::jianta1);

    Button*ta2=new Button(":/set.png");
    ta2->setParent(this);
    ta2->move(610,200);
    connect(ta2,&Button::clicked,this,&diffi::jianta2);

    Button*ta3=new Button(":/set.png");
    ta3->setParent(this);
    ta3->move(300,420);
    connect(ta3,&Button::clicked,this,&diffi::jianta3);

    Button*ta4=new Button(":/set.png");
    ta4->setParent(this);
    ta4->move(300,585);
    connect(ta4,&Button::clicked,this,&diffi::jianta4);

    Button*ta5=new Button(":/set.png");
    ta5->setParent(this);
    ta5->move(560,580);
    connect(ta5,&Button::clicked,this,&diffi::jianta5);


}

//问题所在，加上注释之后就可以了
void diffi::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/map2 1024.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    foreach(tower*tower,tower_list)
        tower->draw(&painter);
}

void diffi::jianta1(){
    tower*new_tower=new tower(QPoint(920,170),":/ta 1.png");
    tower_list.push_back(new_tower);
    update();
}

void diffi::jianta2(){
    tower*new_tower=new tower(QPoint(590,190),":/ta 1.png");
    tower_list.push_back(new_tower);
    update();
}

void diffi::jianta3(){
    tower*new_tower=new tower(QPoint(280,410),":/ta 2.png");
    tower_list.push_back(new_tower);
    update();
}

void diffi::jianta4(){
    tower*new_tower=new tower(QPoint(280,575),":/ta 2.png");
    tower_list.push_back(new_tower);
    update();
}

void diffi::jianta5(){
    tower*new_tower=new tower(QPoint(540,570),":/ta 3.png");
    tower_list.push_back(new_tower);
    update();
}
