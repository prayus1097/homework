#include "tower.h"
#include <QPoint>
#include <QPixmap>
#include <QPainter>

tower::tower(QPoint pos,QString pixfilname) : QObject(0),_pixmap(pixfilname)
{
    _pos=pos;
}

void tower::draw(QPainter *painter){
    painter->drawPixmap(_pos,_pixmap);
}
