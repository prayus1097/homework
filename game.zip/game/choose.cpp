#include "choose.h"
#include <QPaintEvent>
#include <QPainter>
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include "button.h"
#include "easy.h"
#include "diffi.h"

choose::choose(QWidget *parent)
    : QMainWindow(parent)
{
    this->setFixedSize(1024,1024);

    Button *anniu1=new Button(":/jiandan.png");
    anniu1->setParent(this);
    anniu1->move(412,300);

    easy *scene1=new easy;
    connect(anniu1,&QPushButton::clicked,this,[=](){
        this->close();
        scene1->show();
    });

    Button *anniu2=new Button(":/kunnan .png");
    anniu2->setParent(this);
    anniu2->move(412,700);

    diffi *scene2=new diffi;
    connect(anniu2,&QPushButton::clicked,this,[=](){
        this->close();
        scene2->show();
    });

}

void choose::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/guanqiaxuanze beijing.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}

