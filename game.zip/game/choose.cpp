#include "choose.h"
#include <QPaintEvent>
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include <QDebug>
#include "button.h"

choose::choose(QWidget *parent)
    : QMainWindow(parent)
{
    this->setFixedSize(1024,1024);
}

void choose::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/guanqiaxuanze beijing.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
}

