#ifndef BUTTON_H
#define BUTTON_H

#include <QWidget>
#include <QPushButton>

class Button:public QPushButton
{
public:
    Button(QString dizhi);
};

#endif // BUTTON_H
