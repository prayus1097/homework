#ifndef CHOOSE_H
#define CHOOSE_H

#include <QMainWindow>

class choose : public QMainWindow
{
    Q_OBJECT
public:
    explicit choose(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent*);
signals:

};

#endif // CHOOSE_H
