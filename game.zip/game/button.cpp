#include "button.h"
#include <QPixmap>
Button::Button(QString dizhi):QPushButton(0){
    QPixmap pixmap(dizhi);
    this->setFixedSize(pixmap.width(),pixmap.height());
    this->setStyleSheet("QPushButton{border:Opx;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(pixmap.width(),pixmap.height()));
}

