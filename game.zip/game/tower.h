#ifndef TOWER_H
#define TOWER_H

#include <QObject>
#include <QPoint>
#include <QPixmap>

class tower : public QObject
{
    Q_OBJECT
public:
    tower(QPoint pos,QString pixfilname);
    void draw(QPainter*painter);
private:
    QPoint _pos;
    QPixmap _pixmap;

signals:

};

#endif // TOWER_H
